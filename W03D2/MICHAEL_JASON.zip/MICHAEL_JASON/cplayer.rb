require_relative "board.rb"

class ComputerPlayer 
    
    def initialize
    end 

    def prompt(legal_positions) # array of legal positions 
        guessed = {}
        legal_positions.sample
    end 
    

end 